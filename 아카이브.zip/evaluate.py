"""Evaluation runner for MPCBench v2.

Runs evaluation over many tasks, computes scores, and writes logs.
"""

from typing import Dict, Any, List
from pathlib import Path
import json

from config import LOGS_DIR, MODEL_CONFIG_PATH
from task_defs import load_all_tasks, Task, get_planning_meeting_slots
from data_gen import generate_source_data
from agent_runner import run_task
from oracle_validator import validate_data_consistency


def score_planning_answer(task: Task, agent_answer_text: str) -> float:
    """
    Score a planning task answer by checking if agent provides exactly the canonical slots.
    
    Args:
        task: The task definition
        agent_answer_text: The agent's answer text
        
    Returns:
        Score: 1.0 if agent provides exactly the canonical slots (no extra, no missing)
        - 1.0 if all canonical slots are present and no extra slots
        - 0.0 if canonical slots are missing or extra slots are present
        - Partial score if some canonical slots are present but extra slots exist (penalized)
    """
    if task.category != "planning":
        return 0.0
    
    slots = get_planning_meeting_slots(task)
    if not slots:
        return 0.0
    
    # Normalize answer text for matching
    answer_lower = agent_answer_text.lower()
    
    # Extract all date-time pairs mentioned in the answer
    import re
    # Pattern to match dates and times in various formats
    # Look for date patterns followed by time patterns
    mentioned_slots = set()
    
    # Try to extract structured date-time pairs
    # Look for patterns like "December 2, 2025: 14:00 - 14:45" or similar
    date_time_patterns = [
        # "December 2, 2025: 14:00 - 14:45"
        r'(\d{4}-\d{2}-\d{2}|(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+\d{4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+\d{1,2},?\s+\d{4}|\d{1,2}[/-]\d{1,2}[/-]\d{4})[:\s]+(\d{1,2}:\d{2}\s*[-–—to]+\s*\d{1,2}:\d{2})',
        # "14:00 - 14:45" (time only, will match with nearest date)
    ]
    
    # Simpler approach: extract all dates and times separately, then match them
    # Extract dates
    date_patterns = [
        r'(\d{4}-\d{2}-\d{2})',  # 2025-12-02
        r'((?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+\d{4})',  # December 2, 2025
        r'((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s+\d{1,2},?\s+\d{4})',  # Dec 2, 2025
        r'(\d{1,2}[/-]\d{1,2}[/-]\d{4})',  # 12/02/2025
    ]
    
    # Extract times - prioritize full time ranges, avoid single times
    time_patterns = [
        r'(\d{1,2}:\d{2}\s*[-–—to]+\s*\d{1,2}:\d{2})',  # 14:00 - 14:45 (full range)
    ]
    
    # Find all dates and times in the answer
    found_dates = []
    found_times = []
    
    for pattern in date_patterns:
        for match in re.finditer(pattern, answer_lower):
            found_dates.append((match.start(), match.group(1)))
    
    for pattern in time_patterns:
        for match in re.finditer(pattern, answer_lower):
            found_times.append((match.start(), match.group(1)))
    
    # Match dates with nearby times (within reasonable distance)
    # For simplicity, match each date with all times that appear after it until next date
    date_time_pairs = []
    for i, (date_pos, date_str) in enumerate(found_dates):
        next_date_pos = found_dates[i+1][0] if i+1 < len(found_dates) else len(answer_lower)
        for time_pos, time_str in found_times:
            if date_pos < time_pos < next_date_pos:
                date_time_pairs.append((date_str, time_str))
    
    # If no structured pairs found, try to match all dates with all times (less strict)
    if not date_time_pairs and found_dates and found_times:
        for date_str, _ in found_dates:
            for _, time_str in found_times:
                date_time_pairs.append((date_str, time_str))
    
    # Normalize and convert to canonical format for comparison
    def normalize_date(date_str):
        """Convert various date formats to YYYY-MM-DD"""
        import datetime
        # Try parsing different formats
        formats = [
            "%Y-%m-%d",  # 2025-12-02
            "%B %d, %Y",  # December 2, 2025
            "%b %d, %Y",  # Dec 2, 2025
            "%m/%d/%Y",  # 12/02/2025
            "%d/%m/%Y",  # 02/12/2025
            "%m-%d-%Y",  # 12-02-2025
        ]
        for fmt in formats:
            try:
                dt = datetime.datetime.strptime(date_str, fmt)
                return dt.strftime("%Y-%m-%d")
            except:
                continue
        return None
    
    def normalize_time(time_str):
        """Convert various time formats to HH:MM-HH:MM"""
        # Remove spaces and normalize dashes
        time_str_clean = re.sub(r'\s+', '', time_str.lower())
        # Extract times - must have both start and end
        times = re.findall(r'(\d{1,2}):(\d{2})', time_str_clean)
        if len(times) >= 2:
            start_h, start_m = times[0]
            end_h, end_m = times[1]
            return f"{int(start_h):02d}:{start_m}-{int(end_h):02d}:{end_m}"
        # If only one time found, don't create a slot (invalid)
        return None
    
    # Convert agent's mentioned slots to canonical format
    agent_slots = set()
    for date_str, time_str in date_time_pairs:
        norm_date = normalize_date(date_str)
        norm_time = normalize_time(time_str)
        if norm_date and norm_time:
            agent_slots.add((norm_date, norm_time))
    
    # Get canonical slots in same format
    canonical_slots = {(slot["date"], slot["slot"]) for slot in slots}
    
    # Calculate score
    matched_canonical = len(agent_slots & canonical_slots)
    extra_slots = len(agent_slots - canonical_slots)
    missing_canonical = len(canonical_slots - agent_slots)
    
    # Perfect match: all canonical present, no extra
    if matched_canonical == len(canonical_slots) and extra_slots == 0:
        return 1.0
    
    # If there are extra slots or missing canonical, penalize
    if extra_slots > 0 or missing_canonical > 0:
        # Base score from matched canonical
        base_score = matched_canonical / len(canonical_slots) if len(canonical_slots) > 0 else 0.0
        # Penalty for extra slots (reduce score proportionally)
        penalty = min(extra_slots / max(len(agent_slots), 1), 1.0)
        return max(0.0, base_score * (1.0 - penalty * 0.5))  # 50% penalty for extra slots
    
    return 0.0


def evaluate_task(
    task: Task,
    agent_model: str = "gpt-4o-mini",
    generate_data: bool = True,
    tool_context_mode: str = "detailed"
) -> Dict[str, Any]:
    """
    Evaluate a single task.
    
    Args:
        task: The task definition
        agent_model: Model name to use for the agent
        generate_data: Whether to generate source data if it doesn't exist
        
    Returns:
        Dictionary containing evaluation results
    """
    # Generate or load source data
    task_data_dir = LOGS_DIR / task.id / "data"
    if generate_data:
        source_data = generate_source_data(task, task_data_dir)
    else:
        # TODO: Load existing source data
        source_data = {}

    # Validate data consistency
    validation_errors = validate_data_consistency(task, source_data)
    
    # Run agent
    run_log_path = LOGS_DIR / task.id / f"agent-{agent_model}_{tool_context_mode}_run.json"
    agent_result = run_task(task, source_data, agent_model, run_log_path, tool_context_mode=tool_context_mode)

    # Score the answer
    agent_answer_text = agent_result.get("final_answer", "")
    
    if validation_errors:
        # If validation failed, mark scores appropriately
        answer_score = 0.0
    else:
        # Compute scores
        if task.is_planning():
            answer_score = score_planning_answer(task, agent_answer_text)
        else:
            answer_score = 0.0  # TODO: Implement scoring for other categories

    result = {
        "task_id": task.id,
        "agent_model": agent_model,
        "task_category": task.category,
        "metadata": task.metadata,
        "canonical_answer": task.canonical_answer,
        "agent_result": agent_result,
        "validation_errors": validation_errors,
        "scores": {
            "answer_requirements_satisfaction": answer_score
        }
    }

    # Save evaluation result
    eval_log_path = LOGS_DIR / task.id / f"agent-{agent_model}_{tool_context_mode}_eval.json"
    eval_log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(eval_log_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2)

    return result


def evaluate_all_tasks(
    agent_models: List[str] = None,
    generate_data: bool = True,
    tool_context_modes: List[str] = None
) -> Dict[str, Any]:
    """
    Evaluate all tasks.
    
    Args:
        agent_models: List of agent models to test (defaults to config)
        generate_data: Whether to generate source data if it doesn't exist
        
    Returns:
        Dictionary containing evaluation results for all tasks
    """
    if agent_models is None:
        # Load from model_config.json
        try:
            with open(MODEL_CONFIG_PATH, 'r', encoding='utf-8') as f:
                model_config = json.load(f)
                agent_models = model_config.get("agent_models", ["gpt-4o-mini"])
        except Exception:
            agent_models = ["gpt-4o-mini"]

    if tool_context_modes is None:
        tool_context_modes = ["minimal", "detailed"]
    
    tasks = load_all_tasks()
    results = {}
    
    total_combinations = len(tasks) * len(agent_models) * len(tool_context_modes)
    current = 0

    for task_idx, task in enumerate(tasks, 1):
        for model in agent_models:
            for mode in tool_context_modes:
                current += 1
                key = f"{task.id}__{model}__{mode}"
                print(f"[{mode}] Task {task_idx}/{len(tasks)} ({model}): {task.id}...", end=" ", flush=True)
                try:
                    results[key] = evaluate_task(task, model, generate_data, tool_context_mode=mode)
                    print(f"✓")
                except Exception as e:
                    print(f"⚠️  Error: {e}")
                    # Skip this mode and continue with next
                    continue

    return results

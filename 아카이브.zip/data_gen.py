"""Data generation for MPCBench v2.

Generates per-task source data (calendar, slack, contacts, etc.)
based on task requirements using constraint templates.
"""

import json
import re
from typing import Dict, Any, List, Tuple, Optional
from pathlib import Path
from datetime import datetime

from config import get_generator_config
from task_defs import Task, get_planning_meeting_slots


def extract_participant_names(task_description: str) -> List[str]:
    """
    Extract participant names from task description using simple heuristics.
    
    Args:
        task_description: The task description text
        
    Returns:
        List of extracted names (may be empty)
    """
    names = []
    
    # Pattern 1: "for Alice, Bob, and Carol" or "with Alice and Bob"
    patterns = [
        r'\b(for|with)\s+([A-Z][a-z]+(?:\s*,\s*[A-Z][a-z]+)*(?:\s+and\s+[A-Z][a-z]+)?)',
        r'\b([A-Z][a-z]+)\s+and\s+([A-Z][a-z]+)(?:\s+and\s+([A-Z][a-z]+))?',
    ]
    
    for pattern in patterns:
        matches = re.finditer(pattern, task_description, re.IGNORECASE)
        for match in matches:
            text = match.group(0)
            parts = re.split(r'[,,\s]+and\s+|,\s*|\s+', text)
            for part in parts:
                part = part.strip()
                if part and part[0].isupper() and part.isalpha() and len(part) > 2:
                    if part.lower() not in ['for', 'with', 'the', 'and', 'or', 'next', 'week']:
                        if part not in names:
                            names.append(part)
    
    # Pattern 2: Look for capitalized words that aren't at sentence start
    words = task_description.split()
    for i, word in enumerate(words):
        if i > 0 and word[0].isupper() and word.isalpha() and len(word) > 2:
            prev_word = words[i-1].lower() if i > 0 else ""
            if prev_word in ['for', 'with', 'and', 'or'] or prev_word.endswith(','):
                if word not in names:
                    names.append(word)
    
    return names


def generate_participants(task: Task, generator_config: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Generate participant list for a planning task.
    
    Raises ValueError if required config entries are missing.
    """
    names = extract_participant_names(task.task_description)
    
    if not names:
        fallback_names = generator_config.get("fallback_names", [])
        if not fallback_names:
            raise ValueError("Missing generator_config entry: fallback_names (required when no names extracted from task_description)")
        if len(fallback_names) < 3:
            raise ValueError(f"generator_config.fallback_names must have at least 3 names, got {len(fallback_names)}")
        names = fallback_names[:3]
    
    email_domain = generator_config.get("email_domain", "")
    if not email_domain:
        raise ValueError("Missing generator_config entry: email_domain")
    
    participants = []
    for name in names:
        email = f"{name.lower()}@{email_domain}"
        participants.append({
            "name": name,
            "email": email
        })
    
    return participants


def get_weekday_name(date_str: str) -> str:
    """Get weekday name from YYYY-MM-DD date string."""
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        return dt.strftime("%A")
    except:
        return ""


def generate_calendar_events(
    canonical_slot: Dict[str, str],
    participants: List[Dict[str, str]],
    indirection_depth: int,
    fragmentation_depth: int = 1,
    candidate_slots_needed: Optional[int] = None
) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    """
    Generate calendar events using constraint templates.
    
    Args:
        fragmentation_depth: Determines number of distractor slots (higher = more distractors)
        candidate_slots_needed: Override for number of candidate slots (if None, computed from fragmentation_depth)
    
    Returns:
        Tuple of (events list, candidate_slots list)
    """
    from datetime import datetime, timedelta
    
    events = []
    canonical_date = canonical_slot["date"]
    canonical_time = canonical_slot["slot"]
    candidate_slots = [canonical_slot]
    
    # Determine number of candidate slots needed based on fragmentation_depth
    if candidate_slots_needed is None:
        # fragmentation_depth가 높을수록 더 많은 distractor slots 생성
        candidate_slots_needed = max(3, fragmentation_depth + 2)
    
    if indirection_depth == 1:
        # T_CAL_UNIQUE: canonical slot is the only tri-free slot
        for participant in participants:
            events.append({
                "email": participant["email"],
                "date": canonical_date,
                "slot": canonical_time,
                "busy": False
            })
        
        # Mark other slots as busy (at least one participant busy)
        if "-" in canonical_time:
            start_hour = int(canonical_time.split("-")[0].split(":")[0])
            for hour_offset in [-2, -1, 1, 2]:
                hour = start_hour + hour_offset
                if 9 <= hour <= 17:
                    distractor_slot = f"{hour:02d}:00-{hour:02d}:45"
                    for i, participant in enumerate(participants):
                        events.append({
                            "email": participant["email"],
                            "date": canonical_date,
                            "slot": distractor_slot,
                            "busy": (i == 0)  # First participant busy
                        })
    else:
        # T_CAL_MULTI_CANDIDATES: multiple free slots including canonical
        for participant in participants:
            events.append({
                "email": participant["email"],
                "date": canonical_date,
                "slot": canonical_time,
                "busy": False
            })
        
        # Generate distractor slots - same day and other days
        canonical_dt = datetime.strptime(canonical_date, "%Y-%m-%d")
        
        # Same day distractors
        if "-" in canonical_time:
            start_hour = int(canonical_time.split("-")[0].split(":")[0])
            distractor_hours = []
            for hour_offset in [-1, 1, 2, 3, -2]:
                hour = start_hour + hour_offset
                if 9 <= hour <= 17:
                    distractor_hours.append(hour)
            
            same_day_needed = min(candidate_slots_needed - 1, len(distractor_hours))
            for hour in distractor_hours[:same_day_needed]:
                distractor_slot = f"{hour:02d}:00-{hour:02d}:45"
                candidate_slots.append({"date": canonical_date, "slot": distractor_slot})
                for participant in participants:
                    events.append({
                        "email": participant["email"],
                        "date": canonical_date,
                        "slot": distractor_slot,
                        "busy": False
                    })
        
        # Other days distractors (if more candidates needed)
        if len(candidate_slots) < candidate_slots_needed:
            days_to_add = candidate_slots_needed - len(candidate_slots)
            for day_offset in [1, -1, 2, -2, 3, -3]:
                if days_to_add <= 0:
                    break
                other_date_dt = canonical_dt + timedelta(days=day_offset)
                other_date = other_date_dt.strftime("%Y-%m-%d")
                
                # Generate 1-2 slots on this other day
                slots_on_day = min(2, days_to_add)
                for slot_idx in range(slots_on_day):
                    # Use similar time slots (morning, afternoon)
                    if slot_idx == 0:
                        hour = 10  # Morning
                    else:
                        hour = 15  # Afternoon
                    distractor_slot = f"{hour:02d}:00-{hour:02d}:45"
                    candidate_slots.append({"date": other_date, "slot": distractor_slot})
                    for participant in participants:
                        events.append({
                            "email": participant["email"],
                            "date": other_date,
                            "slot": distractor_slot,
                            "busy": False
                        })
                    days_to_add -= 1
    
    return events, candidate_slots


def generate_slack_messages(
    canonical_slot: Dict[str, str],
    candidate_slots: List[Dict[str, str]],
    participants: List[Dict[str, str]],
    indirection_depth: int,
    min_required_source: int,
    fragmentation_depth: int,
    generator_config: Dict[str, Any],
    pattern_type: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Generate Slack messages using constraint templates.
    
    Args:
        pattern_type: "time", "weekday", or "doc_ref" (None = auto-select)
    """
    messages = []
    slack_config = generator_config.get("slack", {})
    
    default_channel = slack_config.get("default_channel", "")
    if not default_channel:
        raise ValueError("Missing generator_config entry: slack.default_channel")
    
    base_user_names = slack_config.get("base_user_names", [])
    
    if indirection_depth == 1:
        return messages
    
    # Get user name for messages
    def get_user_name(index: int) -> str:
        if participants and index < len(participants):
            return participants[index]["name"].lower()
        elif base_user_names and index < len(base_user_names):
            return base_user_names[index]
        else:
            raise ValueError("Missing generator_config entry: slack.base_user_names (required when no participants available)")
    
    if indirection_depth == 2 and min_required_source >= 2:
        # T_SLACK_FILTER_TIME or T_SLACK_FILTER_WEEKDAY
        if pattern_type is None:
            # Auto-select: use time filter if canonical is afternoon, weekday otherwise
            if "-" in canonical_slot["slot"]:
                start_hour = int(canonical_slot["slot"].split("-")[0].split(":")[0])
                pattern_type = "time" if start_hour >= 14 else "weekday"
            else:
                pattern_type = "time"
        
        if pattern_type == "time":
            # T_SLACK_FILTER_TIME
            templates = slack_config.get("time_filter_templates", [])
            if not templates:
                raise ValueError("Missing generator_config entry: slack.time_filter_templates")
            
            template = templates[0]
            if "-" in canonical_slot["slot"]:
                start_hour = int(canonical_slot["slot"].split("-")[0].split(":")[0])
                # Ensure canonical slot satisfies the time filter
                # If canonical is afternoon (>=14), filter allows afternoon
                # If canonical is morning (<14), filter allows morning
                if start_hour >= 14:
                    time_str = f"{start_hour:02d}:00"  # Afternoon filter
                else:
                    time_str = f"{start_hour:02d}:00"  # Morning filter (but canonical is morning)
            else:
                time_str = "14:00"
            message_text = template.format(time=time_str)
            
            # Get timestamps from config
            gmail_config = generator_config.get("gmail", {})
            timestamp_patterns = gmail_config.get("timestamp_patterns", [])
            if not timestamp_patterns:
                raise ValueError("Missing generator_config entry: gmail.timestamp_patterns")
            base_timestamp = timestamp_patterns[0]
            
            if fragmentation_depth == 1:
                messages.append({
                    "channel": default_channel,
                    "user": get_user_name(0),
                    "text": message_text,
                    "timestamp": base_timestamp
                })
            else:
                # Split across messages
                parts = message_text.split(";")
                if len(parts) >= 2:
                    messages.append({
                        "channel": default_channel,
                        "user": get_user_name(0),
                        "text": parts[0] + ".",
                        "timestamp": base_timestamp
                    })
                    next_timestamp = timestamp_patterns[1] if len(timestamp_patterns) > 1 else base_timestamp
                    messages.append({
                        "channel": default_channel,
                        "user": get_user_name(1),
                        "text": parts[1].strip() + ".",
                        "timestamp": next_timestamp
                    })
        
        elif pattern_type == "weekday":
            # T_SLACK_FILTER_WEEKDAY
            templates = slack_config.get("weekday_filter_templates", [])
            if not templates:
                raise ValueError("Missing generator_config entry: slack.weekday_filter_templates")
            
            template = templates[0]
            canonical_weekday = get_weekday_name(canonical_slot["date"])
            # Simple mapping: if canonical is Wed/Thu, disallow Mon/Tue
            if canonical_weekday in ["Wednesday", "Thursday"]:
                days = "Monday and Tuesday"
                allowed_days = "midweek"
            else:
                days = "Monday and Tuesday"
                allowed_days = canonical_weekday
            
            message_text = template.format(days=days, allowed_days=allowed_days)
            gmail_config = generator_config.get("gmail", {})
            timestamp_patterns = gmail_config.get("timestamp_patterns", [])
            if not timestamp_patterns:
                raise ValueError("Missing generator_config entry: gmail.timestamp_patterns")
            base_timestamp = timestamp_patterns[0]
            messages.append({
                "channel": default_channel,
                "user": get_user_name(0),
                "text": message_text,
                "timestamp": base_timestamp
            })
    
    if indirection_depth >= 3:
        # T_SLACK_REFERS_TO_DOC
        doc_templates = slack_config.get("doc_reference_templates", [])
        if not doc_templates:
            raise ValueError("Missing generator_config entry: slack.doc_reference_templates")
        
        drive_config = generator_config.get("drive", {})
        doc_titles = drive_config.get("doc_title_templates", [])
        if not doc_titles:
            raise ValueError("Missing generator_config entry: drive.doc_title_templates")
        
        template = doc_templates[0]
        doc_title = doc_titles[0]
        message_text = template.format(doc_title=doc_title)
        
        gmail_config = generator_config.get("gmail", {})
        timestamp_patterns = gmail_config.get("timestamp_patterns", [])
        if not timestamp_patterns:
            raise ValueError("Missing generator_config entry: gmail.timestamp_patterns")
        base_timestamp = timestamp_patterns[0]
        
        messages.append({
            "channel": default_channel,
            "user": get_user_name(0),
            "text": message_text,
            "timestamp": base_timestamp
        })
    
    return messages


def generate_jira_issues(
    canonical_slot: Dict[str, str],
    candidate_slots: List[Dict[str, str]],
    indirection_depth: int,
    fragmentation_depth: int,
    generator_config: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """
    Generate Jira issues using constraint templates (T_JIRA_CONFLICT_SLOT).
    
    Only applies to distractor slots, never canonical_slot.
    fragmentation_depth determines how many distractors to exclude in this source.
    """
    issues = []
    
    if indirection_depth >= 2:
        jira_config = generator_config.get("jira", {})
        project_keys = jira_config.get("project_keys", [])
        if not project_keys:
            raise ValueError("Missing generator_config entry: jira.project_keys")
        
        conflict_templates = jira_config.get("conflict_templates", [])
        if not conflict_templates:
            raise ValueError("Missing generator_config entry: jira.conflict_templates")
        
        if candidate_slots and len(candidate_slots) > 1:
            # Note: all_canonical_slots is not passed to jira, but we can infer from candidate_slots[0]
            # For jira, we assume only the first canonical slot is in candidate_slots[0]
            # This is a limitation, but jira is typically called before other canonical slots are added
            canonical_keys = {(canonical_slot["date"], canonical_slot["slot"])}
            
            # Exclude distractors based on fragmentation_depth
            # Only exclude non-canonical slots
            distractor_indices = [i for i in range(len(candidate_slots)) 
                                 if (candidate_slots[i]["date"], candidate_slots[i]["slot"]) not in canonical_keys]
            
            num_exclusions = min(len(distractor_indices), max(1, fragmentation_depth))
            
            # Exclude distractors (never exclude canonical slots)
            for idx, i in enumerate(distractor_indices[:num_exclusions]):
                distractor = candidate_slots[i]
                template = conflict_templates[idx % len(conflict_templates)]
                summary = template.format(
                    date=distractor["date"],
                    slot=distractor["slot"]
                )
                issues.append({
                    "issue_key": f"{project_keys[0]}-{120 + i}",
                    "summary": summary,
                    "description": summary,
                    "status": "To Do"
                })
    
    return issues


def generate_drive_files(
    canonical_slot: Dict[str, str],
    candidate_slots: List[Dict[str, str]],
    indirection_depth: int,
    fragmentation_depth: int,
    generator_config: Dict[str, Any],
    all_canonical_slots: List[Dict[str, str]],
    excluded_slots: set = None
) -> List[Dict[str, Any]]:
    """
    Generate Drive files using constraint templates (T_DRIVE_DOC_TIME_NEGATIVE only).
    
    Only applies to distractor slots, never canonical_slot.
    fragmentation_depth determines how many distractors to exclude in this source.
    all_canonical_slots: all canonical slots from the task (to avoid excluding them).
    excluded_slots: set of (date, slot) tuples already excluded by previous sources.
    """
    if excluded_slots is None:
        excluded_slots = set()
    
    files = []
    
    if indirection_depth >= 3:
        drive_config = generator_config.get("drive", {})
        doc_titles = drive_config.get("doc_title_templates", [])
        if not doc_titles:
            raise ValueError("Missing generator_config entry: drive.doc_title_templates")
        
        templates = drive_config.get("doc_time_negative_templates", [])
        if not templates:
            raise ValueError("Missing generator_config entry: drive.doc_time_negative_templates")
        
        if candidate_slots and len(candidate_slots) > 1:
            # Get all canonical slot keys
            canonical_keys = {(slot["date"], slot["slot"]) for slot in all_canonical_slots}
            
            # Exclude distractors based on fragmentation_depth
            # Only exclude non-canonical slots that haven't been excluded yet
            distractor_candidates = [
                (i, candidate_slots[i]) for i in range(len(candidate_slots))
                if (candidate_slots[i]["date"], candidate_slots[i]["slot"]) not in canonical_keys
                and (candidate_slots[i]["date"], candidate_slots[i]["slot"]) not in excluded_slots
            ]
            
            num_exclusions = min(len(distractor_candidates), max(1, fragmentation_depth))
            
            for idx, (i, distractor) in enumerate(distractor_candidates[:num_exclusions]):
                doc_title = doc_titles[idx % len(doc_titles)]
                template = templates[idx % len(templates)]
                text = template.format(
                    date=distractor["date"],
                    slot=distractor["slot"]
                )
                files.append({
                    "file_id": f"file_{i:03d}",
                    "name": doc_title,
                    "text": text
                })
    
    return files


def generate_gmail_threads(
    canonical_slot: Dict[str, str],
    candidate_slots: List[Dict[str, str]],
    participants: List[Dict[str, str]],
    indirection_depth: int,
    fragmentation_depth: int,
    generator_config: Dict[str, Any],
    all_canonical_slots: List[Dict[str, str]],
    excluded_slots: set = None
) -> List[Dict[str, Any]]:
    """
    Generate Gmail threads using constraint templates (T_GMAIL_CANCEL_SLOT only).
    
    Only applies to distractor slots, never canonical_slot.
    fragmentation_depth determines how many distractors to exclude in this source.
    all_canonical_slots: all canonical slots from the task (to avoid excluding them).
    excluded_slots: set of (date, slot) tuples already excluded by previous sources.
    """
    if excluded_slots is None:
        excluded_slots = set()
    threads = []
    
    if indirection_depth >= 3:
        gmail_config = generator_config.get("gmail", {})
        subject_templates = gmail_config.get("subject_templates", [])
        if not subject_templates:
            raise ValueError("Missing generator_config entry: gmail.subject_templates")
        
        from_candidates = gmail_config.get("from_candidates", [])
        to_candidates = gmail_config.get("to_candidates", [])
        timestamp_patterns = gmail_config.get("timestamp_patterns", [])
        if not timestamp_patterns:
            raise ValueError("Missing generator_config entry: gmail.timestamp_patterns")
        
        cancellation_templates = gmail_config.get("cancellation_templates", [])
        if not cancellation_templates:
            raise ValueError("Missing generator_config entry: gmail.cancellation_templates")
        
        if candidate_slots and len(candidate_slots) > 1:
            # Get all canonical slot keys
            canonical_keys = {(slot["date"], slot["slot"]) for slot in all_canonical_slots}
            
            # Exclude distractors based on fragmentation_depth
            # Only exclude non-canonical slots that haven't been excluded yet
            distractor_candidates = [
                (i, candidate_slots[i]) for i in range(len(candidate_slots))
                if (candidate_slots[i]["date"], candidate_slots[i]["slot"]) not in canonical_keys
                and (candidate_slots[i]["date"], candidate_slots[i]["slot"]) not in excluded_slots
            ]
            
            num_exclusions = min(len(distractor_candidates), max(1, fragmentation_depth))
            
            # Get from/to addresses (once, outside loop)
            if participants and len(participants) > 0:
                from_addr = participants[0]["email"]
                to_addrs = [p["email"] for p in participants[1:2]] if len(participants) > 1 else []
            elif from_candidates:
                from_addr = from_candidates[0]
                to_addrs = to_candidates[:2] if to_candidates else []
            else:
                raise ValueError("Missing generator_config entry: gmail.from_candidates (required when no participants available)")
            
            if not to_addrs:
                if to_candidates:
                    to_addrs = to_candidates[:2]
                else:
                    raise ValueError("Missing generator_config entry: gmail.to_candidates (required when no participants available)")
            
            # Generate threads for each distractor to exclude
            for idx, (i, distractor) in enumerate(distractor_candidates[:num_exclusions]):
                template = cancellation_templates[idx % len(cancellation_templates)]
                text = template.format(
                    date=distractor["date"],
                    slot=distractor["slot"]
                )
                
                subject = subject_templates[idx % len(subject_templates)]
                timestamp = timestamp_patterns[idx % len(timestamp_patterns)]
                
                threads.append({
                    "thread_id": f"thread_{i:03d}",
                    "subject": subject,
                    "messages": [{
                        "from": from_addr,
                        "to": to_addrs,
                        "subject": subject,
                        "text": text,
                        "timestamp": timestamp
                    }]
                })
    
    return threads


def generate_source_data(task: Task, output_dir: Path) -> Dict[str, Path]:
    """
    Generate source data files for a task.
    
    Args:
        task: The task definition
        output_dir: Directory to write generated data files
        
    Returns:
        Dictionary mapping source names to file paths
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    
    if task.is_planning():
        return generate_planning_source_data(task, output_dir)
    elif task.is_document() or task.is_email_reply():
        # TODO: Implement richer generation for document and email_reply tasks
        return {}
    else:
        return {}


def generate_planning_source_data(task: Task, output_dir: Path) -> Dict[str, Path]:
    """Generate source data for a planning task using constraint templates."""
    source_data = {}
    generator_config = get_generator_config()
    
    # Generate participants
    participants = generate_participants(task, generator_config)
    
    # Get canonical slots
    slots = get_planning_meeting_slots(task)
    if not slots:
        return source_data
    
    # Use first canonical slot for calendar generation
    # Other canonical slots will be included as free slots in calendar
    canonical_slot = slots[0]
    indirection_depth = task.metadata["indirection_depth"]
    min_required_source = task.metadata["min_required_source"]
    fragmentation_depth = task.metadata["fragmentation_depth"]
    
    # Generate calendar
    calendar_events, candidate_slots = generate_calendar_events(
        canonical_slot, participants, indirection_depth, fragmentation_depth
    )
    
    # Add other canonical slots to calendar and candidate_slots if not already present
    for slot in slots[1:]:
        slot_key = (slot["date"], slot["slot"])
        # Check if already in candidate_slots
        if not any((s["date"], s["slot"]) == slot_key for s in candidate_slots):
            candidate_slots.append(slot)
            # Add events for this canonical slot
            for participant in participants:
                calendar_events.append({
                    "email": participant["email"],
                    "date": slot["date"],
                    "slot": slot["slot"],
                    "busy": False
                })
    calendar_path = output_dir / "calendar.json"
    with open(calendar_path, 'w', encoding='utf-8') as f:
        json.dump({"events": calendar_events}, f, indent=2)
    source_data["calendar"] = calendar_path
    
    # Generate additional sources based on indirection_depth and min_required_source
    if indirection_depth == 1:
        # Only calendar essential
        pass
    elif indirection_depth == 2:
        # Pattern 2A, 2B, or 2C
        if min_required_source >= 2:
            # Choose pattern deterministically based on min_required_source
            pattern_choice = min_required_source % 3
            
            if pattern_choice == 0:
                # Pattern 2A: calendar + slack(time)
                slack_messages = generate_slack_messages(
                    canonical_slot, candidate_slots, participants,
                    indirection_depth, min_required_source, fragmentation_depth,
                    generator_config, pattern_type="time"
                )
                if slack_messages:
                    slack_path = output_dir / "slack.json"
                    with open(slack_path, 'w', encoding='utf-8') as f:
                        json.dump({"messages": slack_messages}, f, indent=2)
                    source_data["slack"] = slack_path
            
            elif pattern_choice == 1:
                # Pattern 2B: calendar + slack(weekday)
                slack_messages = generate_slack_messages(
                    canonical_slot, candidate_slots, participants,
                    indirection_depth, min_required_source, fragmentation_depth,
                    generator_config, pattern_type="weekday"
                )
                if slack_messages:
                    slack_path = output_dir / "slack.json"
                    with open(slack_path, 'w', encoding='utf-8') as f:
                        json.dump({"messages": slack_messages}, f, indent=2)
                    source_data["slack"] = slack_path
            
            else:
                # Pattern 2C: calendar + jira
                jira_issues = generate_jira_issues(
                    canonical_slot, candidate_slots, indirection_depth,
                    fragmentation_depth, generator_config
                )
                if jira_issues:
                    jira_path = output_dir / "jira.json"
                    with open(jira_path, 'w', encoding='utf-8') as f:
                        json.dump({"issues": jira_issues}, f, indent=2)
                    source_data["jira"] = jira_path
    
    elif indirection_depth >= 3:
        # Pattern 3A, 3B, or 3C
        pattern_choice = min_required_source % 3
        
        if pattern_choice == 0:
            # Pattern 3A: slack(doc_ref) + drive(negative) + calendar
            slack_messages = generate_slack_messages(
                canonical_slot, candidate_slots, participants,
                indirection_depth, min_required_source, fragmentation_depth,
                generator_config, pattern_type="doc_ref"
            )
            if slack_messages:
                slack_path = output_dir / "slack.json"
                with open(slack_path, 'w', encoding='utf-8') as f:
                    json.dump({"messages": slack_messages}, f, indent=2)
                source_data["slack"] = slack_path
            
            drive_files = generate_drive_files(
                canonical_slot, candidate_slots, indirection_depth, fragmentation_depth, generator_config, all_canonical_slots=slots, excluded_slots=set()
            )
            if drive_files:
                drive_path = output_dir / "drive.json"
                with open(drive_path, 'w', encoding='utf-8') as f:
                    json.dump({"files": drive_files}, f, indent=2)
                source_data["drive"] = drive_path
        
        elif pattern_choice == 1:
            # Pattern 3B: slack(time/weekday) + jira(conflicts) + calendar
            slack_messages = generate_slack_messages(
                canonical_slot, candidate_slots, participants,
                indirection_depth, min_required_source, fragmentation_depth,
                generator_config, pattern_type="time"
            )
            if slack_messages:
                slack_path = output_dir / "slack.json"
                with open(slack_path, 'w', encoding='utf-8') as f:
                    json.dump({"messages": slack_messages}, f, indent=2)
                source_data["slack"] = slack_path
            
            jira_issues = generate_jira_issues(
                canonical_slot, candidate_slots, indirection_depth,
                fragmentation_depth, generator_config
            )
            if jira_issues:
                jira_path = output_dir / "jira.json"
                with open(jira_path, 'w', encoding='utf-8') as f:
                    json.dump({"issues": jira_issues}, f, indent=2)
                source_data["jira"] = jira_path
            
            # For high min_required_source, also add drive and gmail constraints
            if min_required_source >= 4:
                # Track which slots jira excluded
                jira_excluded_slots = set()
                if jira_issues:
                    import re
                    for issue in jira_issues:
                        summary = issue.get("summary", "")
                        date_match = re.search(r'(\d{4}-\d{2}-\d{2})', summary)
                        slot_match = re.search(r'(\d{2}:\d{2}-\d{2}:\d{2})', summary)
                        if date_match and slot_match:
                            jira_excluded_slots.add((date_match.group(1), slot_match.group(1)))
                
                drive_files = generate_drive_files(
                    canonical_slot, candidate_slots, indirection_depth, fragmentation_depth, generator_config, all_canonical_slots=slots, excluded_slots=jira_excluded_slots
                )
                if drive_files:
                    drive_path = output_dir / "drive.json"
                    with open(drive_path, 'w', encoding='utf-8') as f:
                        json.dump({"files": drive_files}, f, indent=2)
                    source_data["drive"] = drive_path
                
                # Track which slots drive excluded
                drive_excluded_slots = set(jira_excluded_slots)
                if drive_files:
                    import re
                    for file in drive_files:
                        text = file.get("text", "")
                        date_match = re.search(r'(\d{4}-\d{2}-\d{2})', text)
                        slot_match = re.search(r'(\d{2}:\d{2}-\d{2}:\d{2})', text)
                        if date_match and slot_match:
                            drive_excluded_slots.add((date_match.group(1), slot_match.group(1)))
                
                # Add gmail to exclude remaining distractors
                gmail_threads = generate_gmail_threads(
                    canonical_slot, candidate_slots, participants,
                    indirection_depth, fragmentation_depth, generator_config, all_canonical_slots=slots, excluded_slots=drive_excluded_slots
                )
                if gmail_threads:
                    gmail_path = output_dir / "gmail.json"
                    with open(gmail_path, 'w', encoding='utf-8') as f:
                        json.dump({"threads": gmail_threads}, f, indent=2)
                    source_data["gmail"] = gmail_path
        
        else:
            # Pattern 3C: slack(time/weekday) + gmail(cancellations) + optional drive
            slack_messages = generate_slack_messages(
                canonical_slot, candidate_slots, participants,
                indirection_depth, min_required_source, fragmentation_depth,
                generator_config, pattern_type="time"
            )
            if slack_messages:
                slack_path = output_dir / "slack.json"
                with open(slack_path, 'w', encoding='utf-8') as f:
                    json.dump({"messages": slack_messages}, f, indent=2)
                source_data["slack"] = slack_path
            
            gmail_threads = generate_gmail_threads(
                canonical_slot, candidate_slots, participants,
                indirection_depth, fragmentation_depth, generator_config, all_canonical_slots=slots, excluded_slots=set()
            )
            if gmail_threads:
                gmail_path = output_dir / "gmail.json"
                with open(gmail_path, 'w', encoding='utf-8') as f:
                    json.dump({"threads": gmail_threads}, f, indent=2)
                source_data["gmail"] = gmail_path
            
            # Optional drive with negative constraints
            drive_files = generate_drive_files(
                canonical_slot, candidate_slots, indirection_depth, fragmentation_depth, generator_config, all_canonical_slots=slots, excluded_slots=set()
            )
            if drive_files:
                drive_path = output_dir / "drive.json"
                with open(drive_path, 'w', encoding='utf-8') as f:
                    json.dump({"files": drive_files}, f, indent=2)
                source_data["drive"] = drive_path
    
    # Generate contacts if needed
    if min_required_source >= 2:
        contacts_path = output_dir / "contacts.json"
        contacts_config = generator_config.get("contacts", {})
        name_patterns = contacts_config.get("contact_name_patterns", [])
        if not name_patterns:
            raise ValueError("Missing generator_config entry: contacts.contact_name_patterns")
        
        pattern = name_patterns[0]
        contacts_list = []
        for p in participants:
            contact_name = pattern.format(name=p["name"])
            contacts_list.append({
                "name": contact_name,
                "email": p["email"]
            })
        
        with open(contacts_path, 'w', encoding='utf-8') as f:
            json.dump({"contacts": contacts_list}, f, indent=2)
        source_data["contacts"] = contacts_path
    
    return source_data
